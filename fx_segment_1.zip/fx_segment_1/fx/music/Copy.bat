@echo off
chcp 65001 >nul

copy "0.raw" "apaneintheglass.raw" >nul
copy "0.raw" "bigloss1.raw" >nul
copy "0.raw" "bigloss2.raw" >nul
copy "0.raw" "bigwin1.raw" >nul
copy "0.raw" "bigwin2.raw" >nul
copy "0.raw" "bigwin3.raw" >nul
copy "0.raw" "caravan_ambient.raw" >nul
copy "0.raw" "Crusader.raw" >nul
copy "0.raw" "end_music.raw" >nul
copy "0.raw" "flt_narr1.raw" >nul
copy "0.raw" "solovln_01.raw" >nul

copy "1.raw" "astrongspice.raw" >nul

copy "2.raw" "suspense1a.raw" >nul
copy "2.raw" "suspense1b.raw" >nul
copy "2.raw" "suspense2a.raw" >nul
copy "2.raw" "suspense2b.raw" >nul
copy "2.raw" "suspense2c.raw" >nul

copy "3.raw" "drumloop1a.raw" >nul
copy "3.raw" "drumloop1b.raw" >nul
copy "3.raw" "drumloop1c.raw" >nul
copy "3.raw" "Glory_01.raw" >nul
copy "3.raw" "Glory_02.raw" >nul
copy "3.raw" "Glory_03.raw" >nul
copy "3.raw" "Glory_04.raw" >nul
copy "3.raw" "Glory_05.raw" >nul
copy "3.raw" "Glory_06.raw" >nul
copy "3.raw" "honor_02.raw" >nul
copy "3.raw" "honor_03.raw" >nul
copy "3.raw" "honor_04.raw" >nul
copy "3.raw" "honor_05.raw" >nul
copy "3.raw" "percloop1.raw" >nul

copy "4.raw" "caravan.raw" >nul
copy "4.raw" "flt_01.raw" >nul
copy "4.raw" "flt_04.raw" >nul
copy "4.raw" "flt_07.raw" >nul
copy "4.raw" "flt_10.raw" >nul
copy "4.raw" "flt_13.raw" >nul
copy "4.raw" "flt_16.raw" >nul
copy "4.raw" "flt_19.raw" >nul
copy "4.raw" "oud_03.raw" >nul
copy "4.raw" "oud_06.raw" >nul
copy "4.raw" "oud_09.raw" >nul
copy "4.raw" "oud_13.raw" >nul
copy "4.raw" "oud_16.raw" >nul
copy "4.raw" "oud_19.raw" >nul
copy "4.raw" "oud_22.raw" >nul
copy "4.raw" "sand wedgie.raw" >nul
copy "4.raw" "trancefusion.raw" >nul

copy "5.raw" "cameltoe.raw" >nul
copy "5.raw" "Dar Meshq.raw" >nul
copy "5.raw" "flt_03.raw" >nul
copy "5.raw" "flt_06.raw" >nul
copy "5.raw" "flt_09.raw" >nul
copy "5.raw" "flt_12.raw" >nul
copy "5.raw" "flt_15.raw" >nul
copy "5.raw" "flt_18.raw" >nul
copy "5.raw" "oud_02.raw" >nul
copy "5.raw" "oud_05.raw" >nul
copy "5.raw" "oud_08.raw" >nul
copy "5.raw" "oud_12.raw" >nul
copy "5.raw" "oud_15.raw" >nul
copy "5.raw" "oud_18.raw" >nul
copy "5.raw" "oud_21.raw" >nul
copy "5.raw" "oud_24.raw" >nul
copy "5.raw" "thelastdrop.raw" >nul

copy "6.raw" "crusader_solo.raw" >nul
copy "6.raw" "flt_02.raw" >nul
copy "6.raw" "flt_05.raw" >nul
copy "6.raw" "flt_08.raw" >nul
copy "6.raw" "flt_11.raw" >nul
copy "6.raw" "flt_14.raw" >nul
copy "6.raw" "flt_17.raw" >nul
copy "6.raw" "oud_01.raw" >nul
copy "6.raw" "oud_04.raw" >nul
copy "6.raw" "oud_07.raw" >nul
copy "6.raw" "oud_11.raw" >nul
copy "6.raw" "oud_14.raw" >nul
copy "6.raw" "oud_17.raw" >nul
copy "6.raw" "oud_20.raw" >nul
copy "6.raw" "oud_23.raw" >nul
copy "6.raw" "sandalmaker.raw" >nul

exit